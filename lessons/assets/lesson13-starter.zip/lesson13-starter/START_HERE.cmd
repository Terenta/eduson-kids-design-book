@echo off
setlocal
cd /d "%~dp0"
title Eduson Kids - Game Collection

where py >nul 2>nul
if %errorlevel%==0 (
  py app.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python not found. Install it from python.org and enable Add Python to PATH.
    pause
    exit /b 1
  )
  python app.py
)

if errorlevel 1 (
  echo The app stopped with an error. Copy this window into DeepSeek Chat and ask for help.
  pause
)
