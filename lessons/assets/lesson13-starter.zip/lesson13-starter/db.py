"""Локальное хранилище приложения «Игровая коллекция».

Пользователь работает с интерфейсом приложения, а этот файл выполняет
технические операции SQLite. Значения передаются отдельно от SQL-команд,
соединения с базой всегда закрываются.
"""

from __future__ import annotations

import sqlite3
from contextlib import closing
from pathlib import Path


DEFAULT_DB = Path(__file__).with_name("games.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    studio TEXT NOT NULL,
    genre TEXT NOT NULL DEFAULT '',
    rating INTEGER NOT NULL DEFAULT 0 CHECK (rating BETWEEN 0 AND 5),
    is_completed INTEGER NOT NULL DEFAULT 0 CHECK (is_completed IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_games_title ON games(title);
CREATE INDEX IF NOT EXISTS idx_games_studio ON games(studio);
"""


def connect(db_path: str | Path = DEFAULT_DB) -> sqlite3.Connection:
    connection = sqlite3.connect(Path(db_path), timeout=5)
    connection.row_factory = sqlite3.Row
    connection.create_function(
        "CASEFOLD",
        1,
        lambda value: str(value or "").casefold(),
        deterministic=True,
    )
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db(db_path: str | Path = DEFAULT_DB) -> None:
    with closing(connect(db_path)) as connection, connection:
        connection.executescript(SCHEMA)


def add_game(
    title: str,
    studio: str,
    genre: str = "",
    rating: int = 0,
    is_completed: bool = False,
    db_path: str | Path = DEFAULT_DB,
) -> int:
    title = title.strip()
    studio = studio.strip()
    genre = genre.strip()
    rating = int(rating)
    if not 1 <= len(title) <= 160:
        raise ValueError("Название должно содержать от 1 до 160 символов")
    if not 1 <= len(studio) <= 120:
        raise ValueError("Название студии должно содержать от 1 до 120 символов")
    if len(genre) > 80:
        raise ValueError("Название жанра должно быть не длиннее 80 символов")
    if not 0 <= rating <= 5:
        raise ValueError("Оценка должна быть от 0 до 5")

    init_db(db_path)
    with closing(connect(db_path)) as connection, connection:
        cursor = connection.execute(
            """
            INSERT INTO games(title, studio, genre, rating, is_completed)
            VALUES (?, ?, ?, ?, ?)
            """,
            (title, studio, genre, rating, int(bool(is_completed))),
        )
        return int(cursor.lastrowid)


def get_game(game_id: int, db_path: str | Path = DEFAULT_DB) -> dict | None:
    init_db(db_path)
    with closing(connect(db_path)) as connection, connection:
        row = connection.execute(
            "SELECT * FROM games WHERE id = ?", (game_id,)
        ).fetchone()
    return dict(row) if row else None


def search_games(
    query: str = "",
    limit: int = 100,
    db_path: str | Path = DEFAULT_DB,
    *,
    completion_status: bool | None = None,
) -> list[dict]:
    init_db(db_path)
    safe_limit = max(1, min(int(limit), 100))
    needle = f"%{query.strip().casefold()}%"
    with closing(connect(db_path)) as connection, connection:
        rows = connection.execute(
            """
            SELECT id, title, studio, genre, rating, is_completed, created_at
            FROM games
            WHERE (? = '%%' OR CASEFOLD(title) LIKE ? OR CASEFOLD(studio) LIKE ?)
              AND (? IS NULL OR is_completed = ?)
            ORDER BY CASEFOLD(title)
            LIMIT ?
            """,
            (
                needle,
                needle,
                needle,
                None if completion_status is None else int(completion_status),
                None if completion_status is None else int(completion_status),
                safe_limit,
            ),
        ).fetchall()
    return [dict(row) for row in rows]


def set_game_completed(
    game_id: int,
    is_completed: bool,
    db_path: str | Path = DEFAULT_DB,
) -> bool:
    init_db(db_path)
    with closing(connect(db_path)) as connection, connection:
        cursor = connection.execute(
            "UPDATE games SET is_completed = ? WHERE id = ?",
            (int(bool(is_completed)), game_id),
        )
        return cursor.rowcount == 1


def delete_game(game_id: int, db_path: str | Path = DEFAULT_DB) -> bool:
    init_db(db_path)
    with closing(connect(db_path)) as connection, connection:
        cursor = connection.execute("DELETE FROM games WHERE id = ?", (game_id,))
        return cursor.rowcount == 1


def catalog_summary(db_path: str | Path = DEFAULT_DB) -> dict[str, int]:
    init_db(db_path)
    with closing(connect(db_path)) as connection, connection:
        row = connection.execute(
            """
            SELECT COUNT(*) AS total,
                   COALESCE(SUM(is_completed), 0) AS completed_count
            FROM games
            """
        ).fetchone()
    total = int(row["total"])
    completed = int(row["completed_count"])
    return {"total": total, "completed": completed, "planned": total - completed}
