"""Локальное веб-приложение «Игровая коллекция».

Проект не требует внешних библиотек: веб-сервер и SQLite входят в Python.
Обычный запуск — двойной клик по START_HERE.cmd.
"""

from __future__ import annotations

import argparse
import json
import threading
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

try:
    from . import db
except ImportError:  # Прямой запуск `python app.py`.
    import db  # type: ignore


HERE = Path(__file__).resolve().parent
DEFAULT_INDEX = HERE / "index.html"


class GameServer(ThreadingHTTPServer):
    """Сервер хранит пути к интерфейсу и локальной базе."""

    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], database: Path, index_file: Path = DEFAULT_INDEX):
        self.database = Path(database)
        self.index_file = Path(index_file)
        db.init_db(self.database)
        super().__init__(address, GameHandler)


class GameHandler(BaseHTTPRequestHandler):
    server: GameServer

    def log_message(self, _format: str, *_args: Any) -> None:
        """Не выводить технические HTTP-строки в окно запуска."""

    def _send_json(self, payload: Any, status: int = HTTPStatus.OK) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_error_json(self, message: str, status: int) -> None:
        self._send_json({"error": message}, status)

    def _read_json(self) -> dict[str, Any]:
        raw_length = self.headers.get("Content-Length", "0")
        try:
            length = int(raw_length)
        except ValueError as error:
            raise ValueError("Неверный размер запроса") from error
        if length <= 0 or length > 64_000:
            raise ValueError("Запрос пуст или слишком велик")
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("Приложение получило неверные данные") from error
        if not isinstance(value, dict):
            raise ValueError("Ожидался объект с полями игры")
        return value

    def _game_id(self) -> int | None:
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) != 3 or parts[:2] != ["api", "games"]:
            return None
        try:
            value = int(parts[2])
        except ValueError:
            return None
        return value if value > 0 else None

    def do_GET(self) -> None:  # noqa: N802 - имя задаёт http.server
        parsed = urlparse(self.path)
        if parsed.path in {"/", "/index.html"}:
            if not self.server.index_file.exists():
                self._send_error_json("Не найден index.html", HTTPStatus.INTERNAL_SERVER_ERROR)
                return
            body = self.server.index_file.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/api/summary":
            self._send_json(db.catalog_summary(self.server.database))
            return
        if parsed.path == "/api/games":
            query = parse_qs(parsed.query)
            status_name = query.get("status", ["all"])[0]
            status = {"all": None, "completed": True, "planned": False}.get(status_name)
            if status_name not in {"all", "completed", "planned"}:
                self._send_error_json("Неизвестный фильтр", HTTPStatus.BAD_REQUEST)
                return
            games = db.search_games(
                query=query.get("q", [""])[0],
                db_path=self.server.database,
                completion_status=status,
            )
            self._send_json({"games": games})
            return
        self._send_error_json("Такой страницы нет", HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        if urlparse(self.path).path != "/api/games":
            self._send_error_json("Такой команды нет", HTTPStatus.NOT_FOUND)
            return
        try:
            payload = self._read_json()
            game_id = db.add_game(
                str(payload.get("title", "")),
                str(payload.get("studio", "")),
                genre=str(payload.get("genre", "")),
                rating=int(payload.get("rating", 0)),
                is_completed=bool(payload.get("is_completed", False)),
                db_path=self.server.database,
            )
        except (TypeError, ValueError) as error:
            self._send_error_json(str(error), HTTPStatus.BAD_REQUEST)
            return
        self._send_json({"game": db.get_game(game_id, self.server.database)}, HTTPStatus.CREATED)

    def do_PATCH(self) -> None:  # noqa: N802
        game_id = self._game_id()
        if game_id is None:
            self._send_error_json("Неверный адрес игры", HTTPStatus.NOT_FOUND)
            return
        try:
            payload = self._read_json()
        except ValueError as error:
            self._send_error_json(str(error), HTTPStatus.BAD_REQUEST)
            return
        if type(payload.get("is_completed")) is not bool:
            self._send_error_json("Поле is_completed должно быть true или false", HTTPStatus.BAD_REQUEST)
            return
        if not db.set_game_completed(game_id, payload["is_completed"], self.server.database):
            self._send_error_json("Игра не найдена", HTTPStatus.NOT_FOUND)
            return
        self._send_json({"game": db.get_game(game_id, self.server.database)})

    def do_DELETE(self) -> None:  # noqa: N802
        game_id = self._game_id()
        if game_id is None or not db.delete_game(game_id, self.server.database):
            self._send_error_json("Игра не найдена", HTTPStatus.NOT_FOUND)
            return
        self._send_json({"deleted": True})


def create_server(host: str, port: int, database: Path, index_file: Path = DEFAULT_INDEX) -> GameServer:
    """Создать сервер; port=0 позволяет тесту получить свободный порт."""
    return GameServer((host, port), database, index_file)


def main() -> None:
    parser = argparse.ArgumentParser(description="Игровая коллекция")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int)
    parser.add_argument("--db", type=Path, default=db.DEFAULT_DB)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    if args.port is not None:
        server = create_server(args.host, args.port, args.db)
    else:
        server = None
        for candidate in range(8000, 8010):
            try:
                server = create_server(args.host, candidate, args.db)
                break
            except OSError:
                continue
        if server is None:
            raise RuntimeError("Порты 8000–8009 заняты. Закройте старое окно приложения.")

    port = int(server.server_address[1])
    url = f"http://localhost:{port}"
    print(f"Приложение работает: {url}")
    print("Чтобы остановить его, закройте это окно.")
    if not args.no_browser:
        threading.Timer(0.45, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
